package com.cdac.servlet;

public @interface WebServlet {

}
