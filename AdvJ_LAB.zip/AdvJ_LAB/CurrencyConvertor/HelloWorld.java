package com.cdac.component;

public class HelloWorld {

	public String sayHello(String name) {
		return "Hello " + name;
	}
}
